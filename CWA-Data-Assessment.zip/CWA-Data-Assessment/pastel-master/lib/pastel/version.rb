# frozen_string_literal: true

module Pastel
  VERSION = "0.8.0"
end
